#pragma once
#include <Eigen/Dense>

Eigen::MatrixXd cholcovOrEigendecomp(const Eigen::MatrixXd& X);